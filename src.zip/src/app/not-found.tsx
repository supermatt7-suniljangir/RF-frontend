import React from 'react'

const notFound = () => {
  return (
    <div>notFound</div>
  )
}

export default notFound