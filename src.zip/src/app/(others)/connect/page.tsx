const Connect = () => {
    return (
        <div className="flex items-center justify-center w-full h-full text-gray-500">
            Select a chat to start chatting.
        </div>
    );
};

export default Connect;
