export const URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5500/api";
