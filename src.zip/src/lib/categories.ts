export const categories: string[] = [
  "Graphic Design",
  "UI/UX Design",
  "Illustration",
  "Photography",
  "Web Design",
  "3D Design",
  "Branding",
  "Art Direction",
  "Animation",
  "Other",
];
